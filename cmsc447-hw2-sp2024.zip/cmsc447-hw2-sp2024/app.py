from flask import Flask, render_template, request, jsonify
import sqlite3

app = Flask(__name__)

def create_connection():
    return sqlite3.connect('data.db')

def create_table():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            user_id TEXT NOT NULL,
            points INTEGER NOT NULL
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def index():
    create_table()
    return render_template('index.html')

@app.route('/users', methods=['GET'])
def get_users():
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM users')
    users = cursor.fetchall()
    conn.close()
    return jsonify(users)

@app.route('/add_user', methods=['POST'])
def add_user():
    data = request.json
    name = data['name']
    user_id = data['user_id']
    points = data['points']
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('INSERT INTO users (name, user_id, points) VALUES (?, ?, ?)', (name, user_id, points))
    conn.commit()
    conn.close()
    return jsonify({'message': 'User added successfully'})

@app.route('/update_user/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    data = request.json
    name = data['name']
    points = data['points']
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET name = ?, points = ? WHERE id = ?', (name, points, user_id))
    conn.commit()
    conn.close()
    return jsonify({'message': 'User updated successfully'})

@app.route('/delete_user/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'User deleted successfully'})

if __name__ == '__main__':
    app.run(debug=True)