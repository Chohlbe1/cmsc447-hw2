document.addEventListener('DOMContentLoaded', function () {
    var userId = localStorage.getItem('userId');
    var currentName = localStorage.getItem('currentName');
    var currentPoints = localStorage.getItem('currentPoints');
    document.getElementById('name').value = currentName;
    document.getElementById('points').value = currentPoints;

    document.getElementById('update-user-form').addEventListener('submit', function (e) {
        e.preventDefault();
        var newName = document.getElementById('name').value;
        var newPoints = document.getElementById('points').value;
        axios.put('/update_user/' + userId, { name: newName, points: newPoints })
            .then(function () {
                window.location.href = '/';
            })
            .catch(function (error) {
                console.log(error);
            });
    });
});