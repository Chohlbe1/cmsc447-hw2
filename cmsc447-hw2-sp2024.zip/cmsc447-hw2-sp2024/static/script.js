document.addEventListener('DOMContentLoaded', function () {
    loadUsers();

    document.getElementById('add-user-form').addEventListener('submit', function (e) {
        e.preventDefault();
        addUser();
    });
});

function loadUsers() {
    axios.get('/users')
        .then(function (response) {
            displayUsers(response.data);
        })
        .catch(function (error) {
            console.log(error);
        });
}

function displayUsers(users) {
    var usersContainer = document.getElementById('users-container');
    usersContainer.innerHTML = '';
    users.forEach(function (user) {
        var userDiv = document.createElement('div');
        userDiv.innerHTML = '<p><strong>Name:</strong> ' + user[1] + '</p>' +
                            '<p><strong>ID:</strong> ' + user[2] + '</p>' +
                            '<p><strong>Points:</strong> ' + user[3] + '</p>' +
                            '<button onclick="showUpdateForm(' + user[0] + ', \'' + user[1] + '\', ' + user[3] + ')">Update</button>' +
                            '<button onclick="deleteUser(' + user[0] + ')">Delete</button>';
        usersContainer.appendChild(userDiv);
    });
}

function addUser() {
    var name = document.getElementById('name').value;
    var user_id = document.getElementById('user_id').value;
    var points = document.getElementById('points').value;
    axios.post('/add_user', { name: name, user_id: user_id, points: points })
        .then(function () {
            loadUsers();
            document.getElementById('add-user-form').reset();
        })
        .catch(function (error) {
            console.log(error);
        });
}

function showUpdateForm(userId, currentName, currentPoints) {
    var newName = prompt("Enter new name:", currentName);
    var newPoints = prompt("Enter new points:", currentPoints);
    if (newName !== null && newPoints !== null) {
        updateUser(userId, newName, newPoints);
    }
}

function updateUser(userId, newName, newPoints) {
    axios.put('/update_user/' + userId, { name: newName, points: newPoints })
        .then(function () {
            loadUsers();
        })
        .catch(function (error) {
            console.log(error);
        });
}

function deleteUser(userId) {
    axios.delete('/delete_user/' + userId)
        .then(function () {
            loadUsers();
        })
        .catch(function (error) {
            console.log(error);
        });
}