document.addEventListener('DOMContentLoaded', function () {
    var userId = localStorage.getItem('userId');

    document.getElementById('delete-user-form').addEventListener('submit', function (e) {
        e.preventDefault();
        axios.delete('/delete_user/' + userId)
            .then(function () {
                window.location.href = '/';
            })
            .catch(function (error) {
                console.log(error);
            });
    });
});